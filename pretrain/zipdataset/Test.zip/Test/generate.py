import os

def loadLabel():
	dictionary = {}
	idx = 0
	with open('label.txt') as f:
		content = f.readlines()
		for symbol in content:
			symbol = symbol.replace('\n','')

			split = symbol.split(' ')
			try:
				os.mkdir(split[0])
			except:
				pass

loadLabel()